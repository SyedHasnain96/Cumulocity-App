import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-alarm-item',
  templateUrl: './alarm-item.component.html',
  styleUrls: ['./alarm-item.component.css']
})
export class AlarmItemComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
