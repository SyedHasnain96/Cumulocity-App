import { AlarmService } from './../alarm.service';
import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-alarm-list',
  templateUrl: './alarm-list.component.html',
  styleUrls: ['./alarm-list.component.css']
})
export class AlarmListComponent implements OnInit {

  filterForm: FormGroup | undefined;
  alarmsCollection: any = [];
  total: any;
  totalPages: any;
  filter = false;

  constructor(private service: AlarmService) {}

  ngOnInit() {
    this.filterForm = new FormGroup({
      status: new FormControl(''),
      severity: new FormControl(''),
      pageNo: new FormControl(''),
      pageSize: new FormControl('')
    });


    this.service.getAlarmCollection(0, 5, '', '').subscribe(res => {
      this.alarmsCollection = res['alarms'];
      this.total = res['statistics']['count'];
      if(!this.filterForm && this.filterForm !== undefined)
        {
          //this.filterForm.get('pageNo').patchValue(0);
        }
      this.totalPages = res['statistics']['totalPages'];
    });
  }

  

}
