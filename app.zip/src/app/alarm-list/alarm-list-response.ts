export class AlarmListResponse{
    alarms;
}